<?php $__env->startSection('title',$sp->pagejudul.' - '); ?>
<?php $__env->startSection('content'); ?>

			
			<!-- Sub Page Banner
			============================================= -->
			<section class="sub-page-banner text-center" data-stellar-background-ratio="0.3" style="background:url(../<?php echo e($sp->pageimg); ?>) no-repeat  !important;">
				
				<div class="overlay"></div>
				
				<div class="container">
					<h1 class="entry-title"><span><?php echo e($sp->pagejudul); ?></span></h1>
				</div>
				
			</section>
    

    
			<!-- Sub Page Content
			============================================= -->
			<div id="sub-page-content" class="no-padding-bottom clearfix">

    	
				
				<!-- For Patient and Families
				============================================= -->
				<div class="container big-font">
					
					
					<div class="row">
					
						<div class="col-md-10 col-md-offset-1">
						<?php echo $sp->pagedesc; ?>

						</div>
	
					</div>
					
				</div>
				
				
				
				
			<div class="height20"></div>
		
		
    
		</div><!--end sub-page-content-->
    
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>