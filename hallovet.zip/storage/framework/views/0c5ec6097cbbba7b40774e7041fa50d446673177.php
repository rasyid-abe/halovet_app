<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>



<!-- Main Banner
		============================================= -->
<section id="slider" class="tp-banner-container index-rev-slider clearfix">

    <div class="tp-banner">

        <ul>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Fade
					============================================= -->
            <li data-transition="fade" data-slotamount="10" data-thumb="">
                <img src="<?php echo e(asset($s->slidbg)); ?>" alt="image" />
                <?php if(!is_null($s->slidimg)): ?>
                <div class="caption lfr" data-x="770" data-y="100" data-speed="1500" data-start="900" data-easing="easeOutExpo">
                    <img src="<?php echo e(asset($s->slidimg)); ?>" alt="" />
                </div>
                <?php else: ?>
                <?php endif; ?>
                <?php if(!is_null($s->slidjudul)): ?>
                <div class="caption sft big_white" data-x="0" data-y="265" data-speed="1000" data-start="1700" data-easing="easeOutExpo">
                    <strong><?php echo e($s->slidjudul); ?></strong>
                </div>
                <?php else: ?>
                <?php endif; ?>
                <?php if(!is_null($s->sliddesc)): ?>
                <div class="caption sfr medium_grey" data-x="0" data-y="340" data-speed="1000" data-start="2500" data-easing="easeOutExpo">
                    <?php  
                    
                    $edited = $s->sliddesc;
                    $edited = substr($edited, 3, strlen($edited)-7);
                    
                    ?>

                    <?php echo e($edited); ?>



                </div>
                <?php else: ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>




        </ul>

    </div>

</section>
<!-- Latest News
		============================================= -->
<section class="latest-news" id="artikel">

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <h1 class="light text-center" data-aos="flip-left" data-aos-duration="1500"><span>Artikel Terbaru</span></h1>

                <div class="row">
                    <?php $__currentLoopData = $latesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <article class="blog-item  dropshadow" data-aos="zoom-in" data-aos-duration="1500">
                            <div class="blog-thumbnail hvr-grow">
                                <a href="<?php echo e(url('artikel/'.$a->artslug)); ?>"><img alt="" src="<?php echo e(asset($a->artthumbnail)); ?>" style="height:250px !important;"></a>
                            </div>
                            <div class="blog-content">
                                <h4 class="blog-title"><a href="<?php echo e(url('artikel/'.$a->artslug)); ?>"><?php echo e($a->artjudul); ?></a></h4>
                                <p class="blog-meta"><?php echo e(date("d-m-Y", strtotime($a->artdate))); ?></p>

                                <p class="blog-meta">By: <a href="<?php echo e(url('user/'.$a->id)); ?>"><?php echo e($a->name); ?></a> | <a href="<?php echo e(url('kategori/'.$a->catslug)); ?>"><?php echo e($a->catname); ?></a></p>
                                <p><?php echo e(strip_tags(substr($a->artisi,0,150))); ?>.....</p>
                                <a href="<?php echo e(url('artikel/'.$a->artslug)); ?>" class="btn btn-mini btn-rounded hvr-glow rounded-border">Read more</a>
                            </div>
                        </article>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-12" data-aos="fade-up" data-aos-duration="1500">
                        <center><a href="<?php echo e(url('artikel')); ?>" class="btn btn-lg btn-primary rounded-border">Baca Artikel Lainnya</a></center>
                    </div>
                </div>
            </div>



        </div>

    </div>

</section>

<!-- About
		============================================= -->
<section class="latest-news" id="penyakit">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="light text-center" data-aos="flip-right" data-aos-duration="1500"><span>KENALI PENYAKIT HEWAN</span></h1>
                
                <div class="row">

                    <?php $__currentLoopData = $latestp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <article class="blog-item dropshadow rounded-border" data-aos="flip-left" data-aos-duration="1500">
                            <div class="blog-thumbnail hvr-grow">
                                <a href="<?php echo e(url('penyakit/'.$p->penslug)); ?>"><img alt="" src="<?php echo e(asset($p->penthumb)); ?>" style="height:250px !important;"></a>
                            </div>
                            <div class="blog-content">
                                <h4 class="blog-title"><a href="<?php echo e(url('penyakit/'.$p->penslug)); ?>"><?php echo e($p->pennama); ?></a></h4>
                                <p><?php echo e(strip_tags(substr($p->penisi,0,150))); ?>.....</p>
                                <a href="<?php echo e(url('penyakit/'.$p->penslug)); ?>" class="btn btn-mini btn-rounded hvr-glow rounded-border">Read more</a>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-12" data-aos="fade-up" data-aos-duration="1500">
                        <center><a href="<?php echo e(url('penyakit')); ?>" class="btn btn-lg btn-primary rounded-border">Kenali Penyakit Hewan Lainnya</a></center>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>



<!-- Appointment
		============================================= -->
<section class="latest-news" id="konsultasi">

    <div class="container">
   
            <h1 data-aos="flip-left" data-aos-duration="1500" class="light text-center"><span>Konsultasi dengan dokter hewan</span></h1>

        <div class="row" style="margin:10px;">
            <div class="col-md-12">
                <div class="clearfix">
                    <div class="row no-gutters dropshadow rounded-border" data-aos="zoom-in-up" data-aos-duration="1500">
                        <?php $__currentLoopData = $kindex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="col-md-3">
                                <center>
                                    <img src="<?php echo e(asset($k->profilepic)); ?>" style="width: 50px; height: 50px !important;" class="img-responsive img-circle">
                                    <b><?php echo e($k->name); ?></b>
                                </center>
                            </div>
                            <div class="col-md-9">
                                <a href="<?php echo e(url('konsultasi/'.$k->konsslug)); ?>"><?php echo e($k->konsjudul); ?></a>
                                <br>
                                <p><?php echo e(strip_tags(substr($k->konsisi,0,100))); ?>....</p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <br>
                    <center>
                        <a href="<?php echo e(url('konsultasi/baru')); ?>" class="btn btn-md btn-primary rounded-border" data-aos="fade-up" data-aos-duration="1500">Buat Pertanyaan Baru</a>
                        <a href="<?php echo e(url('konsultasi')); ?>" class="btn btn-md btn-info rounded-border" data-aos="fade-up" data-aos-duration="1500">Lihat Diskusi Lainnya</a>
                    </center>

                </div>

            </div>

        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
<script>
    (function() {

        // Revolution slider
        var revapi;
        revapi = jQuery('.tp-banner').revolution({
            delay: 9000,
            startwidth: 1170,
            startheight: 682,
            hideThumbs: 200,
            fullWidth: "on",
            forceFullWidth: "on"
        });

    })();

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>