<?php $__env->startSection('title','Ubah Informasi Peliharaan - '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('mceImageUpload::upload_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/4.7.9/jquery.tinymce.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/4.7.9/tinymce.min.js"></script>

<script type="text/javascript">
    tinymce.init({
        selector: '#editor',
        menubar: false,
        autoresize_overflow_padding: 50,
        theme_advanced_resizing: true,
        width: '100%',
        height: 300,
        autoresize_min_height: 300,
        autoresize_max_height: 600,

        plugins: [
            'advlist autolink link lists charmap preview hr anchor pagebreak',
            'searchreplace wordcount visualblocks visualchars fullscreen insertdatetime nonbreaking',
            'save table contextmenu paste textcolor image imagetools autoresize'
        ],
        toolbar: 'styleselect bold italic | alignleft aligncenter | bullist link image',
        relative_urls: false,
        file_browser_callback: function(field_name, url, type, win) {
            // trigger file upload form
            if (type == 'image') $('#formUpload input').click();
        }
    });
    $(window).resize(function() {
        setTimeout(function() {
            $j('.mceEditor').css('width', '100%').css('minHeight', '240px');
            $j('.mceLayout').css('width', '100%').css('minHeight', '240px');
            $j('.mceIframeContainer').css('width', '100%').css('minHeight', '240px');
            $j('#' + ['editor'] + '_ifr').css('width', '100%').css('minHeight', '240px');
        }, 500)
    });

</script>




<?php $__env->stopSection(); ?>


<!-- Sub Page Content
			============================================= -->
<div id="sub-page-content" class="clearfix">

    <div class="container">

        <div class="row">
            <div class="col-md-4">

                <!-- Categories Widget
							============================================= -->
                <div class="sidebar-widget clearfix ">
                    <div class="card-user-profile-container ">
                        <div class="card-user-profile-inner dropshadow">
                            <center>
                                <div class="card-user-profile-photo">
                                    <img src="<?php echo e(asset($ep->petphoto)); ?>" class="img-responsive img-circle marbot" style="width: 70% !important; height: 70% !important; ">
                                </div>
                                <div class="card-user-profile name">
                                    <b><?php echo e($ep->petname); ?>

                                        <?php if($ep->petsex == 1): ?>
                                        <img src="<?php echo e(url('icon/male.png')); ?>" width="24" height="24">
                                        <?php else: ?>
                                        <img src="<?php echo e(url('icon/female.png')); ?>" width="24" height="24">
                                        <?php endif; ?></b>
                                </div>
                                <label class="label label-primary">Pet Code : <?php echo e($ep->petcode); ?></label>
                                <br>
                                <br>

                                <div class="title">Warna Hewan</div>
                                <div class="card-user-profile warna"><?php echo e($ep->petcolor); ?></div>
                                <div class="title">Jenis Hewan</div>
                                <div class="card-user-profile tipe"><?php if($ep->pettype == 1): ?>
                                    Mamalia
                                    <?php elseif($ep->pettype == 2): ?>
                                    Reptil
                                    <?php elseif($ep->pettype == 3): ?>
                                    Unggas
                                    <?php elseif($ep->pettype == 4): ?>
                                    Amfibi
                                    <?php else: ?>
                                    Tidak terklasifikasi
                                    <?php endif; ?>
                                </div>
                                <div class="title">Status</div>
                                <div class="card-user-profile vaksin"><?php if($ep->petvaksin == 1): ?>
                                    <?php else: ?>
                                    Belum / Tidak Vaksin
                                    <?php endif; ?>
                                    Sudah Vaksin
                                </div>
                                <div class="title">Ciri Hewan</div>
                                <div class="card-user-profile ciri"><?php echo e($ep->petciri); ?></div>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
            <div id="target" class="col-md-8 blog-wrapper clearfix">

                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(url('dashboard/peliharaan#target')); ?>">Peliharaan Saya</a></li>
                    <li class="active"><a href="<?php echo e(url('#')); ?>">Ubah Info Peliharaan</a></li>
                </ul>

                

                <h3 class="light blog-wrapper text-center"><span>Ubah Informasi Peliharaan</span></h3>
                <div class="height20"></div>


                <div class="dropshadow well">
                    <form class="form-horizontal" method="post" action="<?php echo e(url('dashboard/peliharaan/update')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <fieldset>

                            <input type="hidden" name="petcode" value="<?php echo e($ep->petcode); ?>">
                            <div class="row">
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="col-md-2 control-label" for="textinput">Nama Hewan Peliharaan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <input name="petname" value="<?php echo e($ep->petname); ?>" class="form-control" type="text">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-2 control-label" for="textinput">Jenis Hewan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <select id="pettype" name="pettype" class="form-control">

                                            <option value="<?php echo e($ep->pettype); ?>" selected><?php if($ep->pettype == 1): ?>
                                                --> Mamalia
                                                <?php elseif($ep->pettype == 2): ?>
                                                --> Reptil
                                                <?php elseif($ep->pettype == 3): ?>
                                                --> Unggas
                                                <?php elseif($ep->pettype == 4): ?>
                                                --> Amfibi
                                                <?php else: ?>
                                                --> Lain lain
                                                <?php endif; ?></option>

                                            <option value="1">Mamalia</option>
                                            <option value="2">Reptil</option>
                                            <option value="3">Unggas</option>
                                            <option value="4">Amfibi</option>
                                            <option value="5">Lain Lain</option>
                                        </select>
                                    </div>
                                    <label class="col-md-2 control-label">Jenis Hewan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <select id="petdetail" name="petdetail" class="form-control">
                                            <option value="">-- Pilih Jenis -- </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label">Breed Hewan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <input id="petbreed" name="petbreed" value="<?php echo e($ep->petbreed); ?>" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label">Tanggal Lahir Hewan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <input id="tanggallahir" name="petage" value="<?php echo e($ep->petage); ?>" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label">Kode Orang Tua Peliharaan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <input id="petparent" name="petparent" value="<?php echo e($ep->petparent); ?>" class="form-control" type="text">
                                        <small>Kode orang tua hewan jika orang tua hewan pernah di daftarkan di Hallovet</small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label" for="textinput">Warna Hewan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <input id="textinput" name="petcolor" value="<?php echo e($ep->petcolor); ?>" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label">Berat Hewan (dalam Kg)</label>
                                    <div class="col-md-10 col-sm-12">
                                        <input id="petweight" name="petweight" value="<?php echo e($ep->petweight); ?>" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label" for="textinput">Jenis Kelamin Hewan</label>
                                    <div class="col-md-10 col-sm-12">
                                        <select id="petsex" name="petsex" class="form-control">

                                            <option value="<?php echo e($ep->petsex); ?>" selected>
                                                <?php if($ep->petsex == 1): ?>
                                                --> Jantan
                                                <?php else: ?>
                                                --> Betina
                                                <?php endif; ?></option>
                                            <option value="1">Jantan</option>
                                            <option value="2">Betina</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-2 control-label" for="textinput">Status Vaksin</label>
                                    <div class="col-md-10 col-sm-12">
                                        <select id="selectbasic" name="petvaksin" class="form-control">
                                            <option value="<?php echo e($ep->petvaksin); ?>" selected>
                                                <?php if($ep->petvaksin == 1): ?>
                                                --> Belum / Tidak Vaksin
                                                <?php else: ?>
                                                --> Sudah Vaksin
                                                <?php endif; ?>
                                            </option>
                                            <option value="1">Belum Vaksin</option>
                                            <option value="2">Sudah Vaksin</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-2 control-label" for="textinput">Ciri Hewan Peliharaan</label>
                                    <div class="col-md-10 col-sm-12 ">
                                        <textarea name="petciri"><?php echo e($ep->petciri); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2" for="profile">Gambar Thumbnail </label>
                                    <div class="col-md-10">
                                        <img src="<?php echo e(asset($ep->petphoto)); ?>" id="blah" width="150" height="150" class="img-circle img-responsive" />

                                        <input type="file" id="inputprofilepic" name="petphoto" class="validate">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-4 col-md-offset-4">
                                        <button id="singlebutton" name="submit" class="btn btn-lg btn-primary">Ubah</button>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>






            </div>




        </div>

    </div>



</div>
<!--end sub-page-content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>