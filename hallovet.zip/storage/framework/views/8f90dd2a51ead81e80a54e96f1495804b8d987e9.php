<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>



<!-- Sub Page Content
			============================================= -->


<div id="sub-page-content" class="clearfix">

    <!--  INI LOGIN PAGE YG KUBUAT  -->
    <div class="container">
        <div class="row form-login-ya">
            <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <h1 class="text-center login-title">Masuk untuk melanjutkan ke Hallovet</h1>
                <div class="account-wall">
                    <img class="profile-img" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=120" alt="">
                    <form class="form-signin" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input id="email" type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>


                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>

                            <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <button class="btn btn-lg btn-primary btn-block hvr-grow-shadow" type="submit">
                            Masuk</button>
                        <label class="checkbox pull-left">
                            <input type="checkbox" value="remember-me" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            Ingat saya
                        </label>
                        <a href="<?php echo e(route('password.request')); ?>" class="pull-right need-help">Lupa password? </a><span class="clearfix"></span>


                    </form>
                </div>
                <a href="<?php echo e(url('register')); ?>" class="text-center new-account">Buat akun baru </a>
            </div>
        </div>
    </div>
    <!-- INI BATAS LOGIN PAGE YG KUBUAT -->



</div>



<!--end sub-page-content-->





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>