<?php $__env->startSection('title',$detailpet->petname.' - '); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery.gmap.js')); ?>"></script>

<!-- Sub Page Content
			============================================= -->
<div id="sub-page-content" class="clearfix">

    <div class="container">

        <div class="row">

            <div class="col-md-4">

                <!-- Categories Widget
							============================================= -->
                <div class="sidebar-widget clearfix ">
                    <div class="card-user-profile-container ">
                        <div class="card-user-profile-inner dropshadow">
                            <center>
                                <div class="card-user-profile-photo">
                                    <img src="<?php echo e(asset(Auth::user()->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 70% !important; height: 70% !important; ">
                                </div>
                                <div class="card-user-profile name">
                                    <b><?php echo e(Auth::user()->name); ?></b>
                                </div>
                                <?php if(Auth::user()->role == 2): ?>
                                <?php if(Auth::user()->verifadmin == 0): ?>
                                <label style="font-weight: normal; font-size: 80%;" class="label label-warning">Unverified</label>
                                <div class="alert alert-dismissible alert-warning">
                                    <button type="button" class="close pull-right" style="min-width: 10px;" data-dismiss="alert">&times;</button>
                                    <h4 class="text-center">Peringatan</h4>
                                    <p>Anda belum terverifikasi. Mohon lengkapi persyaratan agar akun anda dapat diverifikasi. Silahkan klik <a href="<?php echo e(url('setting/dokter')); ?>" class="alert-link">di sini</a> untuk melengkapi persyaratan. Banyak benefit yang anda dapatkan jika sudah terverifikasi. Silahkan baca keuntungan menjadi verified doctor lebih lanjut <a href="<?php echo e(url('page/keuntungan-menjadi-verified-account')); ?>" class="alert-link">di sini</a>.</p>
                                </div>
                                <?php else: ?>
                                <label class="label label-success">Verified</label>
                                <?php endif; ?>
                                <br>
                                <?php endif; ?>
                            </center>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8 blog-wrapper clearfix">

                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(url('dashboard/peliharaan#target')); ?>">Peliharaan Saya</a></li>
                    <li class="active"><a href="<?php echo e(url('#')); ?>">Detail Peliharaan</a></li>
                </ul>
                <div class="height40"></div>


                <h2 class="text-center light">Detail Informasi <span><?php echo e($detailpet->petname); ?></span></h2>

                <div class="height40"></div>

                <div class="sidebar-widget clearfix ">
                    <div class="card-user-profile-container ">
                        <div class="card-user-profile-inner dropshadow">
                            <center>
                                <div class="card-user-profile-photo">
                                    <img src="<?php echo e(asset($detailpet->petphoto)); ?>" class="img-responsive img-circle marbot" style="width: 40% !important; height: 40% !important; ">
                                </div>
                                <div class="card-user-profile name">
                                    <b><?php echo e($detailpet->petname); ?>

                                        <?php if($detailpet->petsex == 1): ?>
                                        <img src="<?php echo e(url('icon/male.png')); ?>" width="24" height="24">
                                        <?php else: ?>
                                        <img src="<?php echo e(url('icon/female.png')); ?>" width="24" height="24">
                                        <?php endif; ?></b>
                                </div>
                                <label class="label label-primary">Pet Code : <?php echo e($detailpet->petcode); ?></label>
                                <br>
                                <i>Gunakan Pet Code ini di jaringan dokter Hallovet untuk mendapatkan benefit</i>
                            </center>
                            <br>
                            <br>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="title">Warna Hewan</div>
                                    <div class="card-user-profile warna"><?php echo e($detailpet->petcolor); ?></div>
                                    <div class="title">Breed</div>
                                    <div class="card-user-profile warna"><?php echo e($detailpet->petbreed); ?></div>
                                    <div class="title">Jenis Hewan</div>
                                    <div class="card-user-profile tipe"><?php if($detailpet->pettype == 1): ?>
                                        Mamalia - <?php echo e($detailpet->petdetail); ?>

                                        <?php elseif($detailpet->pettype == 2): ?>
                                        Reptil - <?php echo e($detailpet->petdetail); ?>

                                        <?php elseif($detailpet->pettype == 3): ?>
                                        Unggas - <?php echo e($detailpet->petdetail); ?>

                                        <?php elseif($detailpet->pettype == 4): ?>
                                        Amfibi - <?php echo e($detailpet->petdetail); ?>

                                        <?php else: ?>
                                        Lainnya - <?php echo e($detailpet->petdetail); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="title blog-item">Status</div>
                                    <div class="card-user-profile vaksin"><?php if($detailpet->petvaksin == 1): ?>
                                        <?php else: ?>
                                        Belum / Tidak Vaksin
                                        <?php endif; ?>
                                        Sudah Vaksin
                                    </div>
                                    <div class="title">Pet Age</div>
                                    <div class="card-user-profile warna"><?php $a = floor((time() - strtotime('1986-09-16')) / 31556926);
                                     echo $a; ?></div>
                                    <div class="title">Ciri Hewan</div>
                                    <div class="card-user-profile ciri"><?php echo e($detailpet->petciri); ?></div>
                                </div>
                                <div class="col-md-12" style="margin-top: 1em;">
                                    <h5>Riwayat Pemeriksaan Dokter</h5>
                                    <table class="table">
                                            <thead>
                                              <tr>
                                              <th scope="col">Kode Pemeriksaan</th>
                                                <th scope="col">Anamnesa</th>
                                                <th scope="col">Dokter Pemeriksa</th>
                                                <th scope="col">Tanggal</th>
                                                <th scope="col">Aksi</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $per; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                <th scope="row"><?php echo e($p->percode); ?></th>
                                                <td><?php echo e($p->peranamnesa); ?>k</td>
                                                <td><?php echo e($p->name); ?></td>
                                                <td><?php echo e($p->pertanggal); ?></td>
                                                <td><a href="<?php echo e(url('pemeriksaan/detail/'.$p->perid)); ?>" class="btn-sm btn-warning">Detail</a></td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                          </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>



</div>
<!--end sub-page-content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>