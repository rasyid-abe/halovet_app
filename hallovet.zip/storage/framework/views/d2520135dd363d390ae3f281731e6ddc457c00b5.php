<?php $__env->startSection('title','Hewan Peliharaan Saya - '); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery.gmap.js')); ?>"></script>
<!-- Sub Page Content ============================================= -->
<div id="sub-page-content" class="clearfix">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <!-- Categories Widget ============================================= -->
                <div class="sidebar-widget clearfix ">
                    <div class="card-user-profile-container ">
                        <div class="card-user-profile-inner dropshadow">
                        <center>
                                <div class="card-user-profile-photo">
                                    <img src="<?php echo e(asset(Auth::user()->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 70% !important; height: 70% !important; ">
                                </div>
                                <div class="card-user-profile name">
                                    <b><?php echo e(Auth::user()->name); ?></b>
                                </div>
                                <?php if(Auth::user()->role == 2): ?>
                                <?php if(Auth::user()->verifadmin == 0): ?>
                                <label style="font-weight: normal; font-size: 80%;" class="label label-warning">Unverified</label>
                                <div class="alert alert-dismissible alert-warning">
                                    <button type="button" class="close pull-right" style="min-width: 10px;" data-dismiss="alert">&times;</button>
                                    <h4 class="text-center">Peringatan</h4>
                                    <p>Anda belum terverifikasi. Mohon lengkapi persyaratan agar akun anda dapat diverifikasi. Silahkan klik <a href="<?php echo e(url('setting/dokter')); ?>" class="alert-link">di sini</a> untuk melengkapi persyaratan. Banyak benefit yang anda dapatkan jika sudah terverifikasi. Silahkan baca keuntungan menjadi verified doctor lebih lanjut <a href="<?php echo e(url('page/keuntungan-menjadi-verified-account')); ?>" class="alert-link">di sini</a>.</p>
                                </div>
                                <?php else: ?>
                                <label class="label label-success">Verified</label>
                                <?php endif; ?>
                                <br>
                                <?php endif; ?>

                                <div class="title">Bio</div>
                                <div class="card-user-profile biography"><?php echo e(Auth::user()->bio); ?></div>
                                <div class="title">Email</div>
                                <div class="card-user-profile email"><?php echo e(Auth::user()->email); ?></div>
                                <div class="title">No. HP</div>
                                <div class="card-user-profile nohp"><?php echo e(Auth::user()->nohp); ?></div>
                                <div class="title">Alamat</div>
                                <div class="card-user-profile alamat"><?php echo e(Auth::user()->alamat); ?></div>
                                
                                <div class="col-md-12" data-aos="fade-up" data-aos-duration="1500">
                                    <a href="<?php echo e(url('setting#target')); ?>" target="_blank" class="btn btn-lg btn-primary rounded-border" style="text-transform:none;">Ubah Profil</a>
                                    <div class="height20"></div>
                                    <?php if(Auth::user()->role == 2): ?>
                                     <?php if(Auth::user()->verifadmin == 1): ?>
                                    <a href="<?php echo e(url('/taglokasi')); ?>" target="_blank" class="btn btn-lg btn-warning rounded-border" style="text-transform:none;">Input Lokasi Klinik</a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </center>
                        </div>
                    </div>
                </div>

            </div>
            <div id="target" class="col-md-8 blog-wrapper clearfix">
                <?php if(Auth::user()->role == 2): ?>
                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(url('dashboard#target')); ?>">Konsultasi</a></li>
                    <li><a href="<?php echo e(url('dashboard/pemeriksaan#target')); ?>">Ambulatoir</a></li>
                    <li><a href="<?php echo e(url('dashboard/post#target')); ?>">Artikel Saya</a></li>
                    <li class="active"><a href="<?php echo e(url('#')); ?>">Peliharaan Saya</a></li>
                    <li><a href="<?php echo e(url('setting/dokter')); ?>">Pengaturan Dokter</a></li>
                </ul>
                <?php else: ?>
                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(url('dashboard#target')); ?>">Pertanyaan Saya</a></li>
                    <li class="active"><a href="<?php echo e(url('#')); ?>">Peliharaan Saya</a></li>
                </ul>
                <?php endif; ?>
                <div class="height20"></div>

                <h3 class="light text-center"><span>Hewan Peliharaan Saya</span></h3>
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <a href="<?php echo e(url('dashboard/peliharaan/new#target')); ?>" class="btn-default btn-outline hvr-shutter-out-horizontal make-question text-center" data-aos="fade-up" data-aos-duration="1500"><i class="fas fa-plus"></i> Tambah Peliharaan</a>
                    </div>
                </div>
                <div class="height40"></div>
                <div class="row marbot">
                    <?php $__currentLoopData = $mypet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="dropshadow card-user-profile-container blog-item">
                            <div class="card-user-profile-inner ">
                                <center>
                                    <div class="card-user-profile-photo">
                                        <img src="<?php echo e(asset($k->petphoto)); ?>" class="img-responsive img-circle marbot" style="width: 50%; height: 50%;">
                                    </div>
                                    <div class="card-user-profile name">
                                        <b><?php echo e($k->petname); ?>

                                            <?php if($k->petsex == 1): ?>
                                            <img src="<?php echo e(url('icon/male.png')); ?>" width="24" height="24">
                                            <?php else: ?>
                                            <img src="<?php echo e(url('icon/female.png')); ?>" width="24" height="24">
                                            <?php endif; ?>
                                        </b>
                                    </div>
                                    <label class="label label-primary">Pet Code : <?php echo e($k->petcode); ?></label>
                                    <br>
                                    <br>
                                    <div class="title">Breed</div>
                                    <div class="card-user-profile warna"><?php echo e($k->petbreed); ?></div>
                                    <div class="title">Pet Age</div>
                                    <div class="card-user-profile warna"><?php $a = floor((time() - strtotime('.$k->petage.')) / 31556926);
                                     echo $a; ?></div>
                                    <div class="title">Warna Hewan</div>
                                    <div class="card-user-profile warna"><?php echo e($k->petcolor); ?></div>
                                    <div class="title">Berat Hewan</div>
                                    <div class="card-user-profile warna"><?php echo e($k->petweight); ?> Kg</div>
                                    <div class="title">Jenis Hewan</div>
                                    <div class="card-user-profile warna"><?php if($k->pettype == 1): ?>
                                        Mamalia - <?php echo e($k->petdetail); ?>

                                        <?php elseif($k->pettype == 2): ?>
                                        Reptil - <?php echo e($k->petdetail); ?>

                                        <?php elseif($k->pettype == 3): ?>
                                        Unggas - <?php echo e($k->petdetail); ?>

                                        <?php elseif($k->pettype == 4): ?>
                                        Amfibi - <?php echo e($k->petdetail); ?>

                                        <?php else: ?>
                                        Lainnya - <?php echo e($k->petdetail); ?>

                                        <?php endif; ?>
                                    </div>
                                    <div class="title">Status</div>
                                    <div class="card-user-profile warna"><?php if($k->petvaksin == 1): ?>
                                    Sudah Vaksin
                                        <?php else: ?>
                                        Belum / Tidak Vaksin
                                        <?php endif; ?>
                                    </div>
                                    <div class="title">Ciri Hewan</div>
                                    <div class="card-user-profile warna"><?php echo e($k->petciri); ?></div>
                                    <a href="<?php echo e(url('dashboard/peliharaan/detail/'.$k->petcode)); ?>" class="btn btn-sm btn-info">Detail</a>
                                    <a href="<?php echo e(url('dashboard/peliharaan/edit/'.$k->petcode)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(url('dashboard/peliharaan/delete/'.$k->petcode)); ?>" class="btn btn-sm btn-danger">Delete</a>
                                    <a href="<?php echo e(url('dashboard/peliharaan/transfer/'.$k->petcode)); ?>" class="btn btn-sm btn-primary">Transfer</a>
                                </center>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($mypet->links()); ?>

            </div>
        </div>
    </div>
</div>
<!--end sub-page-content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>