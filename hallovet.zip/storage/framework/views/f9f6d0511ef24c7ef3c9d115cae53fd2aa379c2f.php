<?php $__env->startSection('title','Direktori Dokter Hewan - '); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery.gmap.js')); ?>"></script>

<!-- Sub Page Content
			============================================= -->
<div id="sub-page-content" class="clearfix">

    <div class="container">

        <div class="row">
            <aside class="col-md-12 blog-wrapper clearfix">

                <!-- Categories Widget
							============================================= -->
                <div class="sidebar-widget clearfix">

                    <h2 class="text-center light">Cari Berdasar <span>Kota</span></h2>
                    <center>
                        <form method="get" action="<?php echo e(url('dokter')); ?>">
                            <div class="form-group">
                                <div class="col-md-4 col-md-offset-4">
                                   <select id="provinsi" class="form-control">
                                        
                                    </select>
                                    <select id="kabupaten" name="kota" class="form-control">
                                        
                                    </select>
                                  
                                    <div class="col-md-6 col-md-offset-3">
                                        <button type="submit" class="btn btn-primary btn-sm">Cari</button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </center>
                </div>



                <!-- Archives
							============================================= -->

            </aside>
        </div>
        <div class="row">
            <div class="col-md-12 blog-wrapper clearfix">

                <h2 class="text-center light"><span>Dokter Hewan</span></h2>
                <div class="height40"></div>
                <?php if(count($alldok) == 0): ?>
                <center>
                    <p>Maaf, tidak ada dokter hewan yang terdaftar di kota tersebut</p>
                </center>
                <?php else: ?>

                <div class="row">
                    <?php $__currentLoopData = $alldok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="col-md-2">
                            <center>
                                <img src="<?php echo e($a->profilepic); ?>" style="width: 100px; height: 100px;" class="img-responsive img-circle">
                            </center>
                        </div>
                        <div class="col-md-10">
                            <a href="<?php echo e(url('user/'.$a->id)); ?>"><b><?php echo e($a->name); ?></b></a>
                            <?php if($a->verifadmin == 1): ?>
                            <label class="label label-success">Verified</label>
                            <?php else: ?>
                            <label class="label label-warning">Unverified</label><br>

                            <?php endif; ?>
                            <p><b>Alamat Praktek / Klinik</b> : <?php echo e($a->klinik); ?>

                                <?php if(!is_null($a->kotname)): ?>
                                <?php echo e($a->kotname); ?>

                                <?php else: ?>
                                <?php endif; ?>
                                <br>
                                <b>Almamater</b> : <?php echo e($a->lulusan); ?> (<?php echo e($a->tahunlulus); ?>)
                                <?php if(Auth::check()): ?>
                                <br>
                                <b>Telp</b> : <?php echo e($a->nohp); ?></p>
                            <?php else: ?>
                            <br>
                            <p><b>Telp</b> : Silahkan login untuk lihat No Telepon</p>
                            <?php endif; ?>
                            <p><b>Bio</b> : <?php echo e($a->bio); ?><br>
                                <p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <center>
                    <?php echo e($alldok->links()); ?>

                </center>

                <?php endif; ?>

            </div>
        </div>
    </div>
</div>


<!--end sub-page-content-->

<script>
    $(function(){
        namaprovinsi();
    });
    
    $("#provinsi").change(function () {
//        $('#kabupaten').html("<option value='none'>--Kabupaten/Kota--</option>");
//        $('#kecamatan').html("<option value='none'>--Kecamatan--</option>");

        str = $('#provinsi').val();
        if (str != "none") {
            id = $('#provinsi').val();
            nama = $('select[name=provinsi]').find('option[value="' + id + '"]').text();
            $('#namaprov').val(nama);
            namakota(id);
        }
    });
    
    function namaprovinsi() {
        $.get("<?php echo e(route('cariprovinsi')); ?>", function (data) {
            $.each(data, function (index, value) {
                $('#provinsi').append("<option value='" + value.id + "'>" + value.provname + "</option>");
            });
        });
    }

    function namakota(id_prov) {
    $.get("<?php echo e(route('carikota')); ?>?id=" + id_prov, function (data) {
        $.each(data, function (index, value) {
            $('#kabupaten').append("<option value='" + value.kotid + "'>" + value.kotname + "</option>");
        });
    });
} 
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>