<?php $__env->startSection('title',$vk->konsjudul.' - '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('mceImageUpload::upload_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript" src="<?php echo e(asset('js/tinymce/jquery.tinymce.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
<script type="text/javascript">
    tinymce.init({
        selector: '#editor',
        menubar: false,
        height: "300",
        plugins: [
            'autolink link lists pagebreak',
            'searchreplace wordcount insertdatetime nonbreaking',
            'image imagetools'
        ],
        toolbar: 'bold italic link image',
        relative_urls: false,
        file_browser_callback: function(field_name, url, type, win) {
            // trigger file upload form
            if (type == 'image') $('#formUpload input').click();
        }
    });

</script>


<!-- Sub Page Content
			============================================= -->
<div id="sub-page-content" class="clearfix">

    <div class="container">

        <div class="row">

            <div class="col-md-8 blog-wrapper clearfix">
                <a href="<?php echo e(url('konsultasi')); ?>" data-aos="fade-right" data-aos-duration="1500"> <i class="fas fa-arrow-left"></i> Kembali ke daftar pertanyaan</a>
                <br>
                <br>
                <h2 class="light" data-aos="flip-left" data-aos-duration="1500"><?php echo e($vk->konsjudul); ?></h2>
                <br>
                <div class="row" data-aos="fade-right" data-aos-duration="1500">
                    <div class="col-md-2 col-sm-2 col-xs-2" style="max-width:86px; min-width:86px;">

                        <a href="<?php echo e('user/'.$vk->id); ?>"><img src="<?php echo e(asset($vk->profilepic)); ?>" class="img-responsive marbot img-circle" style="width: 56px !important; height: 56px !important;"> </a>

                    </div>
                    <div class="col-xs-8 col-sm-10 col-md-10">

                        
                        <p class="marsot" style="font-size:14px;"><b><?php echo e($vk->name); ?></b>
                            <small class="visible-xs-block hidden-sm hidden-md hidden-lg">Diposting pada <?php echo e(date("d-m-Y", strtotime($vk->konsdate))); ?>

                            </small>

                            <span class="hidden-xs"><small style="float: right;">Diposting pada <?php echo e(date("d-m-Y", strtotime($vk->konsdate))); ?>

                                </small></span>
                        </p>

                        <?php if($vk->role == 1): ?> <p class="marsot" style="font-size:14px;">Anggota</p>


                        <?php elseif($vk->role == 2): ?>
                        <p class="marsot" style="font-size:14px;">Dokter / Veteriner</p>
                        <?php elseif($vk->role == 3): ?>
                        <p class="marsot" style="font-size:14px;">Moderator</p>
                        <?php else: ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row" data-aos="fade-left" data-aos-duration="1500">
                    <div class="col-md-11 col-md-offset-1 col-sm-12 col-xs-12" style="margin-left: 0px !important;">
                        <div class="jawaban">
                            <?php echo $vk->konsisi; ?>

                            <?php if($vk->konswriter == Auth::id()): ?>
                            <?php if($vk->konsstatus == 2): ?>
                            <a href="<?php echo e(url('konsultasi/'.$vk->konsslug.'/edit')); ?>" class="btn btn-sm btn-warning">Edit Post</a>
                            <?php else: ?>
                            <a href="<?php echo e(url('konsultasi/'.$vk->konsslug.'/edit')); ?>" class="btn btn-sm btn-warning btn-disabled">Edit Post</a>
                            <?php endif; ?>
                            <?php else: ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <br>
                <br>

                <div class="share-post clearfix hidden-xs hidden-sm" data-aos="zoom-in-down" data-aos-duration="1500">
                    <label>Share this Post!</label>
                    <ul class="social-rounded">
                        <li data-aos="fade-up" data-aos-duration="1500"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook"></i></a></li>
                        <li data-aos="fade-up" data-aos-duration="1500"><a href="https://twitter.com/home?status=<?php echo e($vk->konsjudul); ?>%20<?php echo e(url()->current()); ?>"><i class="fa fa-twitter"></i></a></li>
                        <li data-aos="fade-up" data-aos-duration="1500"><a href="https://plus.google.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-google-plus"></i></a></li>


                    </ul>
                </div>



                <?php
                $count = count($vj);
                ?>


                <?php if($count > 0): ?>
                <?php $__currentLoopData = $vj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row" id="<?php echo e($j->jawid); ?>" data-aos="fade-right" data-aos-duration="1500">
                    <div class="col-md-2 col-sm-2 col-xs-2" style="max-width:86px; min-width:86px">
                        <a href="<?php echo e('user/'.$j->id); ?>"><img src="<?php echo e(asset($j->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 56px !important; height: 56px !important;">
                        </a>
                        

                    </div>
                    <div class="col-xs-8 col-sm-10 col-md-10 col-md-10">
                        <p class="marsot" style="font-size:14px;"><b><?php echo e($j->name); ?></b>
                            <small class="visible-xs-block hidden-sm hidden-md hidden-lg">Diposting pada <?php echo e(date("d-m-Y", strtotime($j->jawdate))); ?>

                            </small>

                            <span class="hidden-xs"><small style="float: right;">Diposting pada <?php echo e(date("d-m-Y", strtotime($j->jawdate))); ?>

                                </small></span>
                        </p>

                        <?php if($j->role == 1): ?> <p class="marsot" style="font-size:14px;">Anggota</p>


                        <?php elseif($j->role == 2): ?>
                        <p class="marsot" style="font-size:14px;">Dokter / Veteriner</p>
                        <?php elseif($j->role == 3): ?>
                        <p class="marsot" style="font-size:14px;">Moderator</p>
                        <?php else: ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row" data-aos="fade-left" data-aos-duration="1500">
                    <div class="col-md-11 col-md-offset-1 col-sm-12 col-xs-12" style="margin-left: 0px !important;">
                        <div class="jawaban">
                            <?php echo $j->jawisi; ?>


                            <?php if($j->jawwriter == Auth::id()): ?>
                            <a href="<?php echo e(url('editbalasan/'.$j->jawid)); ?>" class="btn btn-sm btn-warning">Edit Jawaban</a>
                            <?php else: ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>




                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <h4>Belum ada jawaban :(</h4>
                <?php endif; ?>
                <?php echo e($vj->links()); ?>

                <br>
                <?php if(Auth::check()): ?>
                <?php if($vk->konstatus == 2 OR $vk->konstatus == 3): ?>
                <center>
                    <h5>Diskusi ini telah ditutup karena telah terjawab oleh dokter hewan</h5>
                    <br>
                    <a href="<?php echo e(url('konsultasi/baru')); ?>" class="btn btn-md btn-primary">Buat Pertanyaan Baru</a>
                </center>
                <?php else: ?>
                <h5>Balas diskusi ini !</h5>
                <form method="post" action="<?php echo e(url('balas/'.$vk->konsslug)); ?>">
                    <?php echo e(csrf_Field()); ?>

                    <textarea class="editor" id="editor" name="jawisi" style="height: 400px !important; width: 100%;"></textarea>
                    <input type="hidden" name="jawthread" value="<?php echo e($vk->konsid); ?>">
                    <input type="hidden" name="slugthread" value="<?php echo e($vk->konsslug); ?>">
                    <br>
                    <button class="btn btn-primary btn-md" type="submit">Balas</button>
                </form>
                <?php endif; ?>
                <?php else: ?>
                <center>
                    <h5>Silahkan <a href="<?php echo e(url('login')); ?>">Login</a> untuk membalas diskusi</h5>
                </center>
                <?php endif; ?>

                <br><br><br><br>
                <h2 class="light">Pertanyaan <span>Terbaru</span></h2>
                <br>
                
                <?php if(count($rk) > 0): ?>
                <?php $__currentLoopData = $rk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="row" data-aos="fade-right" data-aos-duration="1500">
                    <div class="col-xs-2 col-sm-2 col-md-2 " style="max-width:86px; min-width:86px;">
                        <a href="<?php echo e(url('konsultasi/'.$r->konsslug)); ?>"><img src="<?php echo e(asset($r->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 56px !important; height: 56px !important;"></a>
                        

                        
                    </div>
                    <div class="col-xs-8 col-sm-10 col-md-10">
                        <p class="marsot question-title"><a href="<?php echo e(url('konsultasi/'.$r->konsslug)); ?>"><b><?php echo e($r->konsjudul); ?></b></a></p>
                        <p class="marsot" style="font-size:14px;">Oleh: <b><?php echo e($r->name); ?></b>
                            <small class="visible-xs-block hidden-sm hidden-md hidden-lg">Diposting pada <?php echo e(date("d-m-Y", strtotime($r->konsdate))); ?>

                            </small>

                            <span class="hidden-xs"><small style="float: right;">Diposting pada <?php echo e(date("d-m-Y", strtotime($r->konsdate))); ?>

                                </small></span>
                        </p>
                        <?php if($r->konstatus == 1): ?>
                        <?php else: ?>
                        <img src="<?php echo e(asset('icon/checked.svg')); ?>" alt="" style="width:14px; height:14px;">
                        <span class="label label-success" style="font-weight:normal !important;">Sudah dibalas oleh Dokter</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row" data-aos="fade-left" data-aos-duration="1500">
                    <div class="col-md-11 col-md-offset-1 col-sm-12 col-xs-12" style="margin-left: 0px !important;">
                        <div class="jawaban">
                            <?php echo e(strip_tags(substr($r->konsisi,0,200))); ?>...
                        </div>
                        <a href="<?php echo e(url('konsultasi/'.$r->konsslug)); ?>" style="float: right !important;" class="btn btn-mini btn-default btn-rounded hvr-glow">Baca Lebih Lanjut</a>
                    </div>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <?php endif; ?>


            </div><!-- row wrap 9 -->


            <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

    </div>



</div>
<!--end sub-page-content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>