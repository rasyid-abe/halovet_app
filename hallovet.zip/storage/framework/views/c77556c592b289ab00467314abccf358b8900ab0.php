<?php $__env->startSection('title','Dashboard - '); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery.gmap.js')); ?>"></script>

<!-- Sub Page Content
			============================================= -->
<div id="sub-page-content" class="clearfix">

    <div class="container">

        <div class="row">
            <div class="col-md-4">

                <!-- Categories Widget
							============================================= -->
                <div class="sidebar-widget clearfix ">
                    <div class="card-user-profile-container ">
                        <div class="card-user-profile-inner dropshadow">
                            <center>
                                <div class="card-user-profile-photo">
                                    <img src="<?php echo e(asset(Auth::user()->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 70% !important; height: 70% !important; ">
                                </div>
                                <div class="card-user-profile name">
                                    <b><?php echo e(Auth::user()->name); ?></b>
                                </div>
                                <?php if(Auth::user()->role == 2): ?>
                                <?php if(Auth::user()->verifadmin == 0): ?>
                                <label style="font-weight: normal; font-size: 80%;" class="label label-warning">Unverified</label>
                                <div class="alert alert-dismissible alert-warning">
                                    <button type="button" class="close pull-right" style="min-width: 10px;" data-dismiss="alert">&times;</button>
                                    <h4 class="text-center">Peringatan</h4>
                                    <p>Anda belum terverifikasi. Mohon lengkapi persyaratan agar akun anda dapat diverifikasi. Silahkan klik <a href="<?php echo e(url('setting/dokter')); ?>" class="alert-link">di sini</a> untuk melengkapi persyaratan. Banyak benefit yang anda dapatkan jika sudah terverifikasi. Silahkan baca keuntungan menjadi verified doctor lebih lanjut <a href="<?php echo e(url('page/keuntungan-menjadi-verified-account')); ?>" class="alert-link">di sini</a>.</p>
                                </div>
                                <?php else: ?>
                                <label class="label label-success">Verified</label>
                                <?php endif; ?>
                                <br>
                                <?php endif; ?>

                                <div class="title">Bio</div>
                                <div class="card-user-profile biography"><?php echo e(Auth::user()->bio); ?></div>
                                <div class="title">Email</div>
                                <div class="card-user-profile email"><?php echo e(Auth::user()->email); ?></div>
                                <div class="title">No. HP</div>
                                <div class="card-user-profile nohp"><?php echo e(Auth::user()->nohp); ?></div>
                                <div class="title">Alamat</div>
                                <div class="card-user-profile alamat"><?php echo e(Auth::user()->alamat); ?></div>
                                <?php if(Auth::user()->role == 2): ?>
                                <div class="title">Almamater</div>
                                <div class="card-user-profile almamater">
                                    <?php echo e($show->lulusan); ?> (<?php echo e($show->tahunlulus); ?>)
                                </div>
                                <div class="title">Alamat Klinik</div>
                                <div class="card-user-profile klinik">
                                    <?php echo e(Auth::user()->klinik); ?>

                                </div>
                                <?php endif; ?>
                                <div class="col-md-12" data-aos="fade-up" data-aos-duration="1500">
                                    <a href="<?php echo e(url('setting#target')); ?>" target="_blank" class="btn btn-lg btn-primary rounded-border" style="text-transform:none;">Ubah Profil</a>
                                    <div class="height20"></div>
                                    <?php if(Auth::user()->role == 2): ?>
                                     <?php if(Auth::user()->verifadmin == 1): ?>
                                    <a href="<?php echo e(url('/taglokasi')); ?>" target="_blank" class="btn btn-lg btn-warning rounded-border" style="text-transform:none;">Input Lokasi Klinik</a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </center>
                        </div>
                    </div>
                </div>
            </div>



            <div class="col-md-8 blog-wrapper clearfix">
                <?php if(Auth::user()->role == 2): ?>
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#">Konsultasi</a></li>
                    <li><a href="<?php echo e(url('dashboard/pemeriksaan#target')); ?>">Ambulatoir</a></li>
                    <li><a href="<?php echo e(url('dashboard/post#target')); ?>">Artikel Saya</a></li>
                    <li><a href="<?php echo e(url('dashboard/peliharaan#target')); ?>">Peliharaan Saya</a></li>
                    <li><a href="<?php echo e(url('setting/dokter#target')); ?>">Pengaturan Dokter</a></li>
                </ul>
                <?php else: ?>
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#">Pertanyaan Saya</a></li>
                    <li><a href="<?php echo e(url('dashboard/peliharaan#target')); ?>">Peliharaan Saya</a></li>
                </ul>
                <?php endif; ?>


                <div class="height40"></div>


                <?php if(Auth::user()->role == 2): ?>
                <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="row" data-aos="fade-right" data-aos-duration="1500">
                    <div class="col-xs-2 col-sm-2 col-md-2 " style="max-width:86px; min-width:86px;">
                        <a href="<?php echo e(url('konsultasi/'.$k->konsslug)); ?>"><img src="<?php echo e(asset($k->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 56px !important; height: 56px !important;"></a>

                    </div>
                    <div class="col-xs-8 col-sm-10 col-md-10">
                        <p class="marsot question-title"><a href="<?php echo e(url('konsultasi/'.$k->konsslug)); ?>"><b><?php echo e($k->konsjudul); ?></b></a></p>
                        <p class="marsot" style="font-size:14px;">Oleh: <b><?php echo e($k->name); ?></b>
                            <small class="visible-xs-block hidden-sm hidden-md hidden-lg">Diposting pada <?php echo e(date("d-m-Y", strtotime($k->konsdate))); ?>

                            </small>

                            <span class="hidden-xs"><small style="float: right;">Diposting pada <?php echo e(date("d-m-Y", strtotime($k->konsdate))); ?>

                                </small></span>
                        </p>
                        <?php if($k->konstatus == 1): ?>
                        <?php else: ?>
                        <img src="<?php echo e(asset('icon/checked.svg')); ?>" alt="" style="width:14px; height:14px;">
                        <span class="label label-success" style="font-weight:normal !important;">Sudah dibalas oleh Dokter</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row" data-aos="fade-left" data-aos-duration="1500">
                    <div class="col-md-11 col-md-offset-1 col-sm-12 col-xs-12" style="margin-left: 0px !important;">
                        <div class="jawaban">
                            <?php echo e(strip_tags(substr($k->konsisi,0,200))); ?>...
                        </div>
                        <div class="height20"></div>
                        <a href="<?php echo e(url('konsultasi/'.$k->konsslug)); ?>" style="float: right !important;" class="btn btn-mini btn-default btn-rounded hvr-glow">Baca Lebih Lanjut</a>
                    </div>
                </div>

                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php echo e($timeline->links()); ?>


                <?php else: ?>

                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <a href="<?php echo e(url('konsultasi/baru')); ?>" class="btn-default btn-outline hvr-shutter-out-horizontal make-question text-center" data-aos="fade-up" data-aos-duration="1500"><i class="fas fa-pencil-alt"></i> Buat Pertanyaan</a>
                    </div>
                </div>
                <div class="height40"></div>

                <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row" data-aos="fade-right" data-aos-duration="1500">
                    <div class="col-xs-2 col-sm-2 col-md-2 " style="max-width:86px; min-width:86px;">
                        <a href="<?php echo e(url('konsultasi/'.$uks->konsslug)); ?>"><img src="<?php echo e(asset($uks->profilepic)); ?>" class="img-responsive img-circle marbot" style="width: 56px !important; height: 56px !important;"></a>

                    </div>
                    <div class="col-xs-8 col-sm-10 col-md-10">
                        <p class="marsot question-title"><a href="<?php echo e(url('konsultasi/'.$uks->konsslug)); ?>"><b><?php echo e($uks->konsjudul); ?></b></a></p>
                        <p class="marsot" style="font-size:14px;">Oleh: <b><?php echo e($uks->name); ?></b>
                            <small class="visible-xs-block hidden-sm hidden-md hidden-lg">Diposting pada <?php echo e(date("d-m-Y", strtotime($uks->konsdate))); ?>

                            </small>

                            <span class="hidden-xs"><small style="float: right;">Diposting pada <?php echo e(date("d-m-Y", strtotime($uks->konsdate))); ?>

                                </small></span>
                        </p>
                        <?php if($uks->konstatus == 1): ?>
                        <?php else: ?>
                        <img src="<?php echo e(asset('icon/checked.svg')); ?>" alt="" style="width:14px; height:14px;">
                        <span class="label label-success" style="font-weight:normal !important;">Sudah dibalas oleh Dokter</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row" data-aos="fade-left" data-aos-duration="1500">
                    <div class="col-md-11 col-md-offset-1 col-sm-12 col-xs-12" style="margin-left: 0px !important;">
                        <div class="jawaban">
                            <?php echo e(strip_tags(substr($uks->konsisi,0,200))); ?>...
                        </div>
                        <div class="height20"></div>
                        <a href="<?php echo e(url('konsultasi/'.$uks->konsslug)); ?>" style="float: right !important;" class="btn btn-mini btn-default btn-rounded hvr-glow">Baca Lebih Lanjut</a>
                    </div>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($timeline->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!--end sub-page-content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>