<!-- Sidebar
					============================================= -->
<aside class="col-md-4">
    <div class="sidebar-widget clearfix">
        <div class="card-user-profile-container" style="border-radius: 15px;">
            <div class="card-user-profile-inner" style="padding-top: 15px;">
                <?php if(Auth::check()): ?>
                <?php if(Auth::user()->role == 3): ?>
                <center>
                    <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-info">Dashboard</a>
                    <a href="<?php echo e(url('konsultasi/baru')); ?>" class="btn btn-primary">Buat Pertanyaan</a>
                </center>
                <br>
                <?php else: ?>
                <?php endif; ?>
                <?php else: ?>
                <?php endif; ?>
                <h3 class="text-center light" data-aos="flip-left" data-aos-duration="1500">Featured <span>Doctor</span></h3>
                <br>
                <div class="row">
                    <?php $__currentLoopData = $randoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-xs-6 col-sm-6">
                        <center>
                            <a class="hvr-hang" data-aos="fade-left" data-aos-duration="1500" href="<?php echo e(url('user/'.$rd->id)); ?>">
                                <img src="<?php echo e(asset($rd->profilepic)); ?>" class="img-responsive img-circle" style="width: 50px; height: 50px !important;">
                                <b><?php echo e($rd->name); ?></b>
                            </a>
                        </center>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br>
                <a data-aos="fade-left" data-aos-duration="1500" class="hvr-underline-reveal" href="<?php echo e(url('dokter')); ?>" style="float: right">See All</a>

            </div>
        </div>
    </div>
    <div class="sidebar-widget clearfix">
        <div class="card-user-profile-container" style="border-radius: 15px;">
            <div class="card-user-profile-inner" style="padding-top: 15px; text-align: justify;">

                <h3 class="light text-center" data-aos="flip-left" data-aos-duration="1500"><a class="hvr-hang" href="<?php echo e(url('artikel')); ?>">Artikel <span>Terbaru</span></a></h3>
                <?php $__currentLoopData = $randart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="popular-post">

                    <a data-aos="fade-left" data-aos-duration="1500" class="hvr-hang" href="<?php echo e(url('artikel/'.$ra->artslug)); ?>"><img src="<?php echo e(asset($ra->artthumbnail)); ?>" class="img-responsive img-fluid" style="height: 50px !important; width: 50px !important;" alt="">
                        <b><?php echo e($ra->artjudul); ?></b></a> 
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="sidebar-widget clearfix">
        <div class="card-user-profile-container" style="border-radius: 15px;">
            <div class="card-user-profile-inner" style="padding-top: 15px;">

                <h3 class="light text-center" data-aos="flip-left" data-aos-duration="1500"><a class="hvr-hang" href="<?php echo e(url('penyakit')); ?>"><span>Penyakit Hewan</span></a></h3>

                <ul class="tags">
                    <?php $__currentLoopData = $randpen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a data-aos="fade-left" data-aos-duration="1500" class="hvr-hang" href="<?php echo e(url('penyakit/'.$rp->penslug)); ?>"><?php echo e($rp->pennama); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="height40"></div>
            <div class="height20"></div>
        </div>
    </div>
    <div class="sidebar-widget clearfix">

        <?php echo $ad->universalsidebar; ?>

    </div>
</aside>
